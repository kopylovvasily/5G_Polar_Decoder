function out = log2floor(in)
  out = floor(log2(in));
return;
