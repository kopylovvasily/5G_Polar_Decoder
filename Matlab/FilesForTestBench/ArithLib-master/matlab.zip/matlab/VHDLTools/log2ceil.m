function out = log2ceil(in)
  out = ceil(log2(in));
return;
